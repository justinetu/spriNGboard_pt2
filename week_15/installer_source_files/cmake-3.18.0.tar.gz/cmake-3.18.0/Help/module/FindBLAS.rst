.. cmake-module:: ../../Modules/FindBLAS.cmake
